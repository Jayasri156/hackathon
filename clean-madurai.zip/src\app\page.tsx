import Link from 'next/link';
import styles from './page.module.css';

export default function Home() {
  return (
    <main className={styles.main}>
      <div className={styles.bgShape1}></div>
      <div className={styles.bgShape2}></div>

      <div className={styles.container}>
        <h1 className={styles.title}>Clean MadurAI</h1>
        <p className={styles.subtitle}>
          AI-Powered Smart Waste Management. Choose your portal to begin reporting issues or managing city sanitation.
        </p>

        <div className={styles.cardsGrid}>
          {/* Citizen Portal Card */}
          <Link href="/login" className={`glass ${styles.card}`}>
            <div className={`${styles.cardIcon} ${styles.citizenIcon}`}>
              🌱
            </div>
            <h2 className={styles.cardTitle}>Citizen Hub</h2>
            <p className={styles.cardDesc}>Report waste, track complaints, and view the cleanliness heatmap of your ward.</p>
          </Link>

          {/* Admin Portal Card */}
          <Link href="/admin/login" className={`glass ${styles.card}`}>
            <div className={`${styles.cardIcon} ${styles.adminIcon}`}>
              🛡️
            </div>
            <h2 className={styles.cardTitle}>Administrator Login</h2>
            <p className={styles.cardDesc}>Manage complaints, monitor AI predictions, optimize routes, and oversee city health.</p>
          </Link>
        </div>
      </div>
    </main>
  );
}
