'use client';
import dynamic from 'next/dynamic';
import { MapPin } from 'lucide-react';
import styles from './heatmap.module.css';

// Dynamically import the map to avoid SSR issues with Leaflet
const Map = dynamic(() => import('@/components/Map'), {
    ssr: false,
    loading: () => <div className={styles.mapLoading}>Loading City Map...</div>
});

export default function HeatmapPage() {
    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.titleWrapper}>
                    <MapPin size={32} className={styles.titleIcon} />
                    <h1 className={styles.pageTitle}>City Cleanliness Heatmap</h1>
                </div>
                <p className={styles.subtitle}>
                    Interactive view of reported waste issues across Madurai.
                    <span className={styles.legendWrapper}>
                        <span className={styles.legendItem}><span className={styles.dotRed}></span> Pending</span>
                        <span className={styles.legendItem}><span className={styles.dotGreen}></span> Resolved</span>
                    </span>
                </p>
            </header>

            <div className={`glass ${styles.mapWrapper}`}>
                <Map />
            </div>
        </div>
    );
}
