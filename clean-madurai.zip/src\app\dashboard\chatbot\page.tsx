'use client';
import { useState } from 'react';
import { Send, Bot, User } from 'lucide-react';
import styles from './chatbot.module.css';

export default function Chatbot() {
    const [messages, setMessages] = useState([
        { id: 1, text: "Vanakkam! I'm MadurAI Assistant. How can I help you today? You can report a problem, ask about segregation, or check ward health.", sender: 'bot' }
    ]);
    const [input, setInput] = useState('');

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim()) return;

        const newMsg = { id: Date.now(), text: input, sender: 'user' };
        setMessages((prev) => [...prev, newMsg]);
        setInput('');

        // Mock AI Response
        setTimeout(() => {
            setMessages((prev) => [
                ...prev,
                {
                    id: Date.now() + 1,
                    text: "I've recorded your concern. Did you know that keeping organic and plastic waste separate reduces landfill burden by 30%? Let me route you to the \"Report Issue\" page if you have a photo of the area.",
                    sender: 'bot'
                }
            ]);
        }, 1500);
    };

    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <Bot size={28} className={styles.headerIcon} />
                <div>
                    <h1 className={styles.title}>MadurAI Support</h1>
                    <p className={styles.subtitle}>Ask me anything in English or Tamil</p>
                </div>
            </div>

            <div className={`glass ${styles.chatWindow}`}>
                <div className={styles.messageBox}>
                    {messages.map((m) => (
                        <div key={m.id} className={`${styles.messageWrapper} ${m.sender === 'user' ? styles.wrapperUser : styles.wrapperBot}`}>
                            <div className={styles.avatar}>
                                {m.sender === 'bot' ? <Bot size={20} /> : <User size={20} />}
                            </div>
                            <div className={`${styles.message} ${m.sender === 'user' ? styles.msgUser : styles.msgBot}`}>
                                {m.text}
                            </div>
                        </div>
                    ))}
                </div>

                <form onSubmit={handleSend} className={styles.inputArea}>
                    <input
                        type="text"
                        placeholder="Type your message..."
                        className={styles.input}
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                    />
                    <button type="submit" className={styles.sendBtn} disabled={!input.trim()}>
                        <Send size={20} />
                    </button>
                </form>
            </div>
        </div>
    );
}
