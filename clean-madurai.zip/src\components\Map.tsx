'use client';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

export default function LeafletMap() {
    const center: [number, number] = [9.9252, 78.1198]; // Madurai Coordinates

    // Mock complaints data
    const complaints = [
        { id: 1, lat: 9.93, lng: 78.12, status: 'pending', ward: 'Anna Nagar' },
        { id: 2, lat: 9.92, lng: 78.11, status: 'resolved', ward: 'SS Colony' },
        { id: 3, lat: 9.91, lng: 78.13, status: 'pending', ward: 'KK Nagar' },
    ];

    return (
        <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%', borderRadius: 'var(--radius-md)' }}>
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {complaints.map(comp => (
                <CircleMarker
                    key={comp.id}
                    center={[comp.lat, comp.lng]}
                    pathOptions={{
                        color: comp.status === 'pending' ? '#ef4444' : '#10b981',
                        fillColor: comp.status === 'pending' ? '#ef4444' : '#10b981',
                        fillOpacity: 0.6
                    }}
                    radius={8}
                >
                    <Popup>
                        <strong>{comp.ward}</strong><br />
                        Status: {comp.status}
                    </Popup>
                </CircleMarker>
            ))}
        </MapContainer>
    );
}
