'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { Shield, LayoutDashboard, ListTodo, Map, Route, Leaf, LogOut, Menu, X } from 'lucide-react';
import styles from '../dashboard.module.css';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    useEffect(() => {
        const role = localStorage.getItem('userRole');
        if (role !== 'ADMIN') {
            router.push('/admin/login');
        }
    }, [router]);

    const toggleMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

    const navItems = [
        { label: 'Analytics', href: '/admin', icon: <LayoutDashboard size={20} /> },
        { label: 'Complaints', href: '/admin/complaints', icon: <ListTodo size={20} /> },
        { label: 'City Map', href: '/admin/heatmap', icon: <Map size={20} /> },
        { label: 'Route Optimizer', href: '/admin/routes', icon: <Route size={20} /> },
        { label: 'Compost Health', href: '/admin/compost', icon: <Leaf size={20} /> },
    ];

    return (
        <div className={styles.layout}>
            {/* Sidebar Navigation */}
            <aside className={`${styles.sidebar} ${isMobileMenuOpen ? styles.sidebarOpen : ''}`} style={{ borderRightColor: 'rgba(59, 130, 246, 0.2)' }}>
                <Link href="/" className={styles.logo} style={{ color: 'var(--secondary)' }}>
                    <Shield size={24} /> MadurAI Admin
                </Link>
                <button className={styles.mobileMenuBtn} onClick={toggleMenu} style={{ position: 'absolute', right: '1rem', top: '1.5rem' }}>
                    <X size={24} />
                </button>

                <nav className={styles.nav}>
                    {navItems.map((item) => {
                        const isActive = pathname === item.href;
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={`${styles.navItem} ${isActive ? styles.navItemActive : ''}`}
                                style={isActive ? { background: 'var(--secondary)' } : {}}
                                onClick={() => setIsMobileMenuOpen(false)}
                            >
                                {item.icon}
                                {item.label}
                            </Link>
                        );
                    })}

                    <button onClick={() => { localStorage.clear(); router.push('/'); }} className={`${styles.navItem} ${styles.logout}`}>
                        <LogOut size={20} />
                        Logout
                    </button>
                </nav>
            </aside>

            {/* Main Content Area */}
            <main className={styles.mainContent}>
                <header className={styles.header}>
                    <button className={styles.mobileMenuBtn} onClick={toggleMenu}>
                        <Menu size={24} />
                    </button>
                    <div className={styles.pageTitle}>Sanitation Control Center</div>
                    <div className={styles.userProfile}>
                        <div className={styles.avatar} style={{ background: 'var(--secondary)' }}>Gov</div>
                    </div>
                </header>

                <div className={styles.contentArea}>
                    {children}
                </div>
            </main>
        </div>
    );
}
