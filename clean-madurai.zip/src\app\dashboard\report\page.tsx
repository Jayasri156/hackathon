'use client';
import { useState, useRef } from 'react';
import { Camera, MapPin, UploadCloud, AlertTriangle } from 'lucide-react';
import styles from './report.module.css';
import { useRouter } from 'next/navigation';

export default function ReportIssue() {
    const router = useRouter();
    const [photo, setPhoto] = useState<string | null>(null);
    const [location, setLocation] = useState<string>('');
    const [isLocating, setIsLocating] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const imageUrl = URL.createObjectURL(file);
            setPhoto(imageUrl);
        }
    };

    const getLocation = () => {
        setIsLocating(true);
        if ("geolocation" in navigator) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setLocation(`Lat: ${position.coords.latitude.toFixed(4)}, Lng: ${position.coords.longitude.toFixed(4)}`);
                    setIsLocating(false);
                },
                (error) => {
                    console.error(error);
                    setLocation('Location access denied');
                    setIsLocating(false);
                }
            );
        } else {
            setLocation('Geolocation not supported');
            setIsLocating(false);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!photo || !location) return alert("Please provide a photo and location.");

        setIsSubmitting(true);
        // Simulate API call and AI Processing
        setTimeout(() => {
            setIsSubmitting(false);
            alert('Issue Reported successfully! AI classified as: Mixed Waste. Severity: High.');
            router.push('/dashboard');
        }, 2000);
    };

    return (
        <div className={styles.container}>
            <h1 className={styles.pageTitle}>Report a Cleanliness Issue</h1>
            <p className={styles.subtitle}>Help us keep Madurai clean by reporting unsegregated waste or overflowing bins.</p>

            <form onSubmit={handleSubmit} className={`glass ${styles.formCard}`}>

                {/* Photo Upload Section */}
                <div className={styles.section}>
                    <label className={styles.label}>Evidence (Required)</label>
                    <div
                        className={`${styles.photoArea} ${photo ? styles.hasPhoto : ''}`}
                        onClick={() => !photo && fileInputRef.current?.click()}
                    >
                        {photo ? (
                            <div className={styles.photoPreview}>
                                {/* eslint-disable-next-line @next/next/no-img-element */}
                                <img src={photo} alt="Waste evidence" className={styles.img} />
                                <button type="button" onClick={(e) => { e.stopPropagation(); setPhoto(null); }} className={styles.removePhotoBtn}>
                                    Change Photo
                                </button>
                            </div>
                        ) : (
                            <div className={styles.uploadPlaceholder}>
                                <Camera size={48} className={styles.uploadIcon} />
                                <p>Tap to take a photo or upload</p>
                            </div>
                        )}
                        <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            ref={fileInputRef}
                            onChange={handlePhotoUpload}
                            className={styles.hiddenInput}
                        />
                    </div>
                </div>

                {/* Location Section */}
                <div className={styles.section}>
                    <label className={styles.label}>Location Details (Required)</label>
                    <div className={styles.locationControls}>
                        <button type="button" onClick={getLocation} className={styles.btnSecondary} disabled={isLocating}>
                            <MapPin size={18} /> {isLocating ? 'Locating...' : 'Get Current Location'}
                        </button>
                        <input
                            type="text"
                            className={styles.input}
                            value={location}
                            readOnly
                            placeholder="Coordinates will appear here"
                            required
                        />
                    </div>
                    <select className={styles.select} required defaultValue="">
                        <option value="" disabled>Select Ward (Fallback)</option>
                        <option value="anna">Anna Nagar</option>
                        <option value="kk">KK Nagar</option>
                        <option value="tpk">Thiruparankundram</option>
                        <option value="ss">SS Colony</option>
                    </select>
                </div>

                {/* AI Info Banner */}
                <div className={styles.aiBanner}>
                    <AlertTriangle size={20} className={styles.aiIcon} />
                    <div>
                        <strong>AI Auto-Classification</strong>
                        <p>Our AI will automatically categorize the waste (Plastic/Organic/Mixed) and assign severity once submitted.</p>
                    </div>
                </div>

                <button type="submit" className={styles.submitBtn} disabled={isSubmitting || !photo || !location}>
                    {isSubmitting ? 'Analyzing Media...' : <><UploadCloud size={20} /> Submit Report</>}
                </button>
            </form>
        </div>
    );
}
