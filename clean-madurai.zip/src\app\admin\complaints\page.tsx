'use client';
import { useState } from 'react';
import { MoreVertical, Check, Trash2, Filter } from 'lucide-react';
import styles from './complaints.module.css';

export default function ComplaintsTable() {
    const [complaints] = useState([
        { id: '#COMP-1049', ward: 'Anna Nagar', category: 'Mixed waste', severity: 'High', date: '2026-02-28', status: 'Pending' },
        { id: '#COMP-1048', ward: 'SS Colony', category: 'Plastic waste', severity: 'Medium', date: '2026-02-28', status: 'Resolved' },
        { id: '#COMP-1047', ward: 'KK Nagar', category: 'Organic waste', severity: 'Low', date: '2026-02-27', status: 'Pending' },
        { id: '#COMP-1046', ward: 'Palanganatham', category: 'Mixed waste', severity: 'High', date: '2026-02-26', status: 'Resolved' },
    ]);

    return (
        <div className={styles.container}>
            <div className={styles.header}>
                <h1 className={styles.pageTitle}>Complaints Management</h1>
                <button className={styles.filterBtn}>
                    <Filter size={18} /> Filters
                </button>
            </div>

            <div className={`glass ${styles.tableContainer}`}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ward</th>
                            <th>AI Category</th>
                            <th>Severity</th>
                            <th>Date Reported</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {complaints.map((comp) => (
                            <tr key={comp.id}>
                                <td className={styles.idCol}>{comp.id}</td>
                                <td>{comp.ward}</td>
                                <td>{comp.category}</td>
                                <td>
                                    <span className={`${styles.severityBadge} ${comp.severity === 'High' ? styles.sevHigh : comp.severity === 'Medium' ? styles.sevMed : styles.sevLow}`}>
                                        {comp.severity}
                                    </span>
                                </td>
                                <td className={styles.dateCol}>{comp.date}</td>
                                <td>
                                    <span className={`${styles.statusBadge} ${comp.status === 'Pending' ? styles.statPending : styles.statResolved}`}>
                                        {comp.status}
                                    </span>
                                </td>
                                <td>
                                    <div className={styles.actions}>
                                        {comp.status === 'Pending' && (
                                            <button className={styles.actionResolve} title="Mark Resolved"><Check size={16} /></button>
                                        )}
                                        <button className={styles.actionDelete} title="Delete"><Trash2 size={16} /></button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
