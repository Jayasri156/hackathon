'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import styles from '../../auth.module.css';
import { ArrowLeft, Shield } from 'lucide-react';

export default function AdminLogin() {
    const router = useRouter();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        // Default mock login credentials check
        if (email === 'admin@madurai.gov' && password === 'admin') {
            localStorage.setItem('userRole', 'ADMIN');
            router.push('/admin');
        } else {
            alert("Invalid credentials! Try admin@madurai.gov / admin");
        }
    };

    return (
        <div className={styles.authContainer}>
            <div className={styles.authCard}>
                <Link href="/" className={styles.backLink}>
                    <ArrowLeft size={16} /> Back
                </Link>

                <div className={styles.header}>
                    <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                        <Shield size={48} color="var(--secondary)" />
                    </div>
                    <h1 className={styles.title}>Admin Portal</h1>
                    <p className={styles.subtitle}>Secure login for city officials and sanitation workers.</p>
                </div>

                <form className={styles.form} onSubmit={handleLogin}>
                    <div className={styles.inputGroup}>
                        <label className={styles.label}>Official ID / Email</label>
                        <input
                            type="email"
                            className={styles.input}
                            placeholder="admin@madurai.gov"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className={styles.inputGroup}>
                        <label className={styles.label}>Password</label>
                        <input
                            type="password"
                            className={styles.input}
                            placeholder="••••••••"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>

                    <button type="submit" className={styles.btnPrimary} style={{ background: 'var(--secondary)' }}>
                        Authenticate
                    </button>
                </form>
            </div>
        </div>
    );
}
