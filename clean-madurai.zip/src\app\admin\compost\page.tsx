'use client';
import { useState, useEffect } from 'react';
import { Leaf, Droplets, Thermometer, Wind, AlertTriangle } from 'lucide-react';
import styles from './compost.module.css';

export default function CompostDashboard() {
    const [data, setData] = useState({
        moisture: 45,
        temp: 55,
        methane: 12,
        health: 'Good'
    });

    // Mock live sensor updates
    useEffect(() => {
        const interval = setInterval(() => {
            setData(prev => ({
                ...prev,
                moisture: Math.min(100, Math.max(0, prev.moisture + (Math.random() - 0.5) * 2)),
                temp: Math.min(80, Math.max(20, prev.temp + (Math.random() - 0.5) * 1.5)),
                methane: Math.min(50, Math.max(0, prev.methane + (Math.random() - 0.2) * 1)),
            }));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.titleWrapper}>
                    <Leaf size={32} className={styles.titleIcon} />
                    <h1 className={styles.pageTitle}>Compost Health Monitor</h1>
                </div>
                <p className={styles.subtitle}>Real-time IoT sensor data from central municipal composting yard.</p>
            </header>

            <div className={styles.grid}>
                <div className={`glass ${styles.sensorCard}`}>
                    <Droplets size={32} className={styles.moistureIcon} />
                    <div className={styles.sensorInfo}>
                        <div className={styles.sensorLabel}>Moisture Level</div>
                        <div className={styles.sensorValue}>{data.moisture.toFixed(1)}%</div>
                        <div className={styles.sensorIdeal}>Ideal: 40-60%</div>
                    </div>
                </div>

                <div className={`glass ${styles.sensorCard}`}>
                    <Thermometer size={32} className={styles.tempIcon} />
                    <div className={styles.sensorInfo}>
                        <div className={styles.sensorLabel}>Internal Temp</div>
                        <div className={styles.sensorValue}>{data.temp.toFixed(1)}°C</div>
                        <div className={styles.sensorIdeal}>Ideal: 50-65°C</div>
                    </div>
                </div>

                <div className={`glass ${styles.sensorCard}`}>
                    <Wind size={32} className={styles.gasIcon} />
                    <div className={styles.sensorInfo}>
                        <div className={styles.sensorLabel}>Methane (CH4)</div>
                        <div className={styles.sensorValue}>{data.methane.toFixed(1)} ppm</div>
                        <div className={styles.sensorIdeal}>Alert if &gt; 25 ppm</div>
                    </div>
                </div>
            </div>

            <div className={`glass ${styles.statusPanel} ${data.methane > 25 ? styles.statusAlert : styles.statusGood}`}>
                <div className={styles.statusHeader}>
                    {data.methane > 25 ? <AlertTriangle size={24} /> : <CheckCircle size={24} />}
                    <h2>{data.methane > 25 ? 'Warning: High Gas Levels' : 'System Health: Optimal'}</h2>
                </div>
                <p>{data.methane > 25 ? 'Methane levels exceeding safety margins in Bin C. Suggesting manual turning immediately.' : 'Compost pile is maturing efficiently. Moisture and temperature are within ideal ranges.'}</p>
            </div>
        </div>
    );
}

function CheckCircle(props: any) {
    return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
}
