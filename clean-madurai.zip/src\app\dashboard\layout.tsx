'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useState, useEffect } from 'react';
import { Home, Camera, Map, Award, LogOut, Menu, X, MessageSquare } from 'lucide-react';
import styles from '../dashboard.module.css';

export default function CitizenLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const router = useRouter();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [userName, setUserName] = useState('Citizen');

    useEffect(() => {
        const role = localStorage.getItem('userRole');
        if (!role || role === 'ADMIN') {
            router.push('/login');
        }
        setUserName(role === 'GUEST' ? 'Guest' : 'Citizen');
    }, [router]);

    const toggleMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

    const navItems = [
        { label: 'Overview', href: '/dashboard', icon: <Home size={20} /> },
        { label: 'Report Issue', href: '/dashboard/report', icon: <Camera size={20} /> },
        { label: 'Heatmap', href: '/dashboard/heatmap', icon: <Map size={20} /> },
        { label: 'Leaderboard', href: '/dashboard/leaderboard', icon: <Award size={20} /> },
        { label: 'Chatbot', href: '/dashboard/chatbot', icon: <MessageSquare size={20} /> },
    ];

    return (
        <div className={styles.layout}>
            {/* Sidebar Navigation */}
            <aside className={`${styles.sidebar} ${isMobileMenuOpen ? styles.sidebarOpen : ''}`}>
                <Link href="/" className={styles.logo}>
                    🌱 MadurAI
                </Link>
                <button className={styles.mobileMenuBtn} onClick={toggleMenu} style={{ position: 'absolute', right: '1rem', top: '1.5rem' }}>
                    <X size={24} />
                </button>

                <nav className={styles.nav}>
                    {navItems.map((item) => {
                        const isActive = pathname === item.href;
                        return (
                            <Link
                                key={item.href}
                                href={item.href}
                                className={`${styles.navItem} ${isActive ? styles.navItemActive : ''}`}
                                onClick={() => setIsMobileMenuOpen(false)}
                            >
                                {item.icon}
                                {item.label}
                            </Link>
                        );
                    })}

                    <button onClick={() => { localStorage.clear(); router.push('/'); }} className={`${styles.navItem} ${styles.logout}`}>
                        <LogOut size={20} />
                        Logout
                    </button>
                </nav>
            </aside>

            {/* Main Content Area */}
            <main className={styles.mainContent}>
                <header className={styles.header}>
                    <button className={styles.mobileMenuBtn} onClick={toggleMenu}>
                        <Menu size={24} />
                    </button>
                    <div className={styles.pageTitle}>Citizen Portal</div>
                    <div className={styles.userProfile}>
                        <div className={styles.avatar}>{userName.charAt(0)}</div>
                    </div>
                </header>

                <div className={styles.contentArea}>
                    {children}
                </div>
            </main>
        </div>
    );
}
