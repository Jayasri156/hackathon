'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import styles from '../auth.module.css';
import { ArrowLeft, User } from 'lucide-react';

export default function CitizenLogin() {
    const router = useRouter();
    const [phoneNumber, setPhoneNumber] = useState('');

    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (phoneNumber.length > 5) {
            // Mock login via localstorage or just push route
            localStorage.setItem('userRole', 'CITIZEN');
            router.push('/dashboard');
        }
    };

    const skipLogin = () => {
        localStorage.setItem('userRole', 'GUEST');
        router.push('/dashboard');
    }

    return (
        <div className={styles.authContainer}>
            <div className={styles.authCard}>
                <Link href="/" className={styles.backLink}>
                    <ArrowLeft size={16} /> Back
                </Link>

                <div className={styles.header}>
                    <h1 className={styles.title}>Citizen Login</h1>
                    <p className={styles.subtitle}>Welcome back! Enter your phone number to continue or proceed as guest.</p>
                </div>

                <form className={styles.form} onSubmit={handleLogin}>
                    <div className={styles.inputGroup}>
                        <label className={styles.label}>Phone Number</label>
                        <input
                            type="tel"
                            className={styles.input}
                            placeholder="+91 98765 43210"
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            required
                        />
                    </div>

                    <button type="submit" className={styles.btnPrimary}>
                        Get OTP
                    </button>
                </form>

                <div className={styles.divider}>OR</div>

                <button onClick={skipLogin} className={styles.btnGuest}>
                    <User size={18} /> Continue as Guest
                </button>
            </div>
        </div>
    );
}
