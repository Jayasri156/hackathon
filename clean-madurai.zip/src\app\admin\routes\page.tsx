'use client';
import { useState } from 'react';
import { Truck, Map as MapIcon, RotateCw, CheckCircle2, Navigation } from 'lucide-react';
import styles from './routes.module.css';

export default function RouteOptimizer() {
    const [isOptimizing, setIsOptimizing] = useState(false);
    const [optimized, setOptimized] = useState(false);

    const trucks = [
        { id: 'TN-58-A-1234', driver: 'Muthu', zone: 'North (Anna Nagar)', status: 'Idle', load: '0%' },
        { id: 'TN-58-B-9876', driver: 'Karthik', zone: 'South (TPK)', status: 'Active', load: '65%' },
        { id: 'TN-58-C-4567', driver: 'Ramesh', zone: 'Central (SS Colony)', status: 'Active', load: '90%' },
    ];

    const handleOptimization = () => {
        setIsOptimizing(true);
        setOptimized(false);
        setTimeout(() => {
            setIsOptimizing(false);
            setOptimized(true);
        }, 2500);
    };

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.titleWrapper}>
                    <RouteIcon size={32} className={styles.titleIcon} />
                    <h1 className={styles.pageTitle}>AI Route Optimizer</h1>
                </div>
                <div className={styles.headerActions}>
                    <button
                        className={`${styles.btnPrimary} ${isOptimizing ? styles.btnLoading : ''}`}
                        onClick={handleOptimization}
                        disabled={isOptimizing}
                    >
                        {isOptimizing ? <RotateCw className={styles.spin} size={20} /> : <Navigation size={20} />}
                        {isOptimizing ? 'Calculating Optimal Paths...' : 'Generate New Routes'}
                    </button>
                </div>
            </header>

            {optimized && (
                <div className={styles.successBanner}>
                    <CheckCircle2 size={24} className={styles.successIcon} />
                    <div>
                        <strong>Routes Successfully Optimized!</strong>
                        <p>Algorithm achieved a 24% reduction in estimated fuel compared to standard routes.</p>
                    </div>
                </div>
            )}

            <div className={styles.contentGrid}>
                <div className={styles.listSection}>
                    <h2 className={styles.sectionTitle}>Active Fleet</h2>
                    <div className={styles.fleetList}>
                        {trucks.map(truck => (
                            <div key={truck.id} className={`glass ${styles.truckCard}`}>
                                <div className={styles.truckIconWrapper}>
                                    <Truck size={24} />
                                </div>
                                <div className={styles.truckInfo}>
                                    <h3 className={styles.truckId}>{truck.id}</h3>
                                    <div className={styles.truckMeta}>Driver: {truck.driver} • {truck.zone}</div>
                                </div>
                                <div className={styles.truckStats}>
                                    <span className={`${styles.statusBadge} ${truck.status === 'Idle' ? styles.statIdle : styles.statActive}`}>
                                        {truck.status}
                                    </span>
                                    <div className={styles.loadIndicator}>
                                        <div className={styles.loadTrack}>
                                            <div className={styles.loadFill} style={{ width: truck.load, background: parseInt(truck.load) > 80 ? '#ef4444' : '#10b981' }}></div>
                                        </div>
                                        <span className={styles.loadText}>{truck.load} Load</span>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className={`glass ${styles.mapSection}`}>
                    <div className={styles.mockMap}>
                        <MapIcon size={64} className={styles.mockMapIcon} />
                        <p className={styles.mockMapText}>Interactive Map Component (Leaflet)<br />[Route Polylines rendering here]</p>
                        {isOptimizing && <div className={styles.mapOverlay}><div className={styles.scanline}></div></div>}
                    </div>
                </div>
            </div>
        </div>
    );
}

function RouteIcon(props: any) {
    return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="6" cy="19" r="3"></circle><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15"></path><circle cx="18" cy="5" r="3"></circle></svg>
}
