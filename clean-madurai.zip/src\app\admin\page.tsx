'use client';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    Title,
    Tooltip,
    Legend,
    ArcElement
} from 'chart.js';
import { Line, Doughnut, Bar } from 'react-chartjs-2';
import styles from './admin-dashboard.module.css';
import { Activity, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend
);

export default function AdminDashboard() {
    const lineData = {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [
            {
                label: 'Issues Reported',
                data: [12, 19, 15, 25, 22, 30, 28],
                borderColor: 'rgba(59, 130, 246, 1)',
                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                tension: 0.4,
            },
        ],
    };

    const doughnutData = {
        labels: ['Plastic', 'Organic', 'Mixed'],
        datasets: [
            {
                data: [45, 25, 30],
                backgroundColor: [
                    'rgba(239, 68, 68, 0.8)',
                    'rgba(16, 185, 129, 0.8)',
                    'rgba(245, 158, 11, 0.8)',
                ],
                borderWidth: 0,
            },
        ],
    };

    const barData = {
        labels: ['Anna Nagar', 'KK Nagar', 'SS Colony', 'Palanganatham'],
        datasets: [
            {
                label: 'Pending Cases',
                data: [12, 19, 3, 5],
                backgroundColor: 'rgba(59, 130, 246, 0.8)',
            },
        ],
    };

    const stats = [
        { label: 'Total Reports', value: '1,284', icon: <Activity size={24} />, color: 'var(--secondary)' },
        { label: 'High Severity', value: '42', icon: <AlertTriangle size={24} />, color: '#ef4444' },
        { label: 'Pending', value: '156', icon: <Clock size={24} />, color: '#f59e0b' },
        { label: 'Resolved (7d)', value: '312', icon: <CheckCircle size={24} />, color: '#10b981' },
    ];

    return (
        <div className={styles.container}>
            <h1 className={styles.pageTitle}>Analytics Overview</h1>

            <div className={styles.statsGrid}>
                {stats.map((stat, i) => (
                    <div key={i} className={`glass ${styles.statCard}`}>
                        <div className={styles.iconWrapper} style={{ color: stat.color, background: `${stat.color}20` }}>
                            {stat.icon}
                        </div>
                        <div>
                            <div className={styles.statValue}>{stat.value}</div>
                            <div className={styles.statLabel}>{stat.label}</div>
                        </div>
                    </div>
                ))}
            </div>

            <div className={styles.chartsGrid}>
                <div className={`glass ${styles.chartCard} ${styles.colSpan2}`}>
                    <h2 className={styles.chartTitle}>7-Day Prediction Forecast (LSTM Mock)</h2>
                    <div className={styles.chartWrapper}>
                        <Line data={lineData} options={{ maintainAspectRatio: false }} />
                    </div>
                </div>

                <div className={`glass ${styles.chartCard}`}>
                    <h2 className={styles.chartTitle}>AI Waste Classification</h2>
                    <div className={styles.chartWrapper}>
                        <Doughnut data={doughnutData} options={{ maintainAspectRatio: false, cutout: '70%' }} />
                    </div>
                </div>

                <div className={`glass ${styles.chartCard} ${styles.colSpan3}`}>
                    <h2 className={styles.chartTitle}>Ward Performance (Pending Issues)</h2>
                    <div className={styles.chartWrapper}>
                        <Bar data={barData} options={{ maintainAspectRatio: false }} />
                    </div>
                </div>
            </div>
        </div>
    );
}
