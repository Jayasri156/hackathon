import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Clean MadurAI',
  description: 'AI-Powered Smart Waste Management PWA',
  manifest: '/manifest.json',
  themeColor: '#2dd4bf',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/icon512_rounded.png" />
      </head>
      <body>
        {children}
      </body>
    </html>
  );
}
