'use client';
import dynamic from 'next/dynamic';
import { MapPin } from 'lucide-react';
import styles from '../../dashboard/heatmap/heatmap.module.css';

// Reuse the citizen heatmap map component for Admin view
const Map = dynamic(() => import('@/components/Map'), {
    ssr: false,
    loading: () => <div className={styles.mapLoading}>Loading City Map...</div>
});

export default function AdminHeatmapPage() {
    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.titleWrapper}>
                    <MapPin size={32} className={styles.titleIcon} />
                    <h1 className={styles.pageTitle}>Sanitation GPS Tracking</h1>
                </div>
                <p className={styles.subtitle}>
                    City-wide interactive heatmap of active issues and deployed trucks.
                    <span className={styles.legendWrapper}>
                        <span className={styles.legendItem}><span className={styles.dotRed}></span> Pending</span>
                        <span className={styles.legendItem}><span className={styles.dotGreen}></span> Resolved</span>
                    </span>
                </p>
            </header>

            <div className={`glass ${styles.mapWrapper}`}>
                <Map />
            </div>
        </div>
    );
}
