'use client';
import { Award, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import styles from './leaderboard.module.css';

export default function Leaderboard() {
    const wards = [
        { id: 1, name: 'Anna Nagar', score: 92, status: 'up', rank: 1 },
        { id: 2, name: 'KK Nagar', score: 88, status: 'same', rank: 2 },
        { id: 3, name: 'Palanganatham', score: 85, status: 'up', rank: 3 },
        { id: 4, name: 'SS Colony', score: 72, status: 'down', rank: 4 },
        { id: 5, name: 'Thiruparankundram', score: 65, status: 'down', rank: 5 },
    ];

    return (
        <div className={styles.container}>
            <header className={styles.header}>
                <div className={styles.titleWrapper}>
                    <Award size={32} className={styles.titleIcon} />
                    <h1 className={styles.pageTitle}>Cleanest Wards</h1>
                </div>
                <p className={styles.subtitle}>
                    Real-time ranking of Madurai wards based on citizen reports and resolution speed.
                </p>
            </header>

            <div className={`glass ${styles.board}`}>
                <div className={styles.boardHeader}>
                    <div className={styles.colRank}>Rank</div>
                    <div className={styles.colWard}>Ward Name</div>
                    <div className={styles.colScore}>Health Score</div>
                    <div className={styles.colTrend}>Trend</div>
                </div>

                <div className={styles.list}>
                    {wards.map((ward) => (
                        <div key={ward.id} className={`${styles.row} ${ward.rank <= 3 ? styles.topRank : ''}`}>
                            <div className={styles.colRank}>
                                <span className={`${styles.rankBadge} ${ward.rank === 1 ? styles.gold : ward.rank === 2 ? styles.silver : ward.rank === 3 ? styles.bronze : ''}`}>
                                    #{ward.rank}
                                </span>
                            </div>
                            <div className={styles.colWard}>{ward.name}</div>
                            <div className={styles.colScore}>
                                <div className={styles.progressTrack}>
                                    <div
                                        className={styles.progressFill}
                                        style={{
                                            width: `${ward.score}%`,
                                            background: ward.score > 80 ? 'var(--primary)' : ward.score > 70 ? '#f59e0b' : 'var(--accent)'
                                        }}
                                    />
                                </div>
                                <span className={styles.scoreText}>{ward.score}/100</span>
                            </div>
                            <div className={styles.colTrend}>
                                {ward.status === 'up' && <TrendingUp size={20} className={styles.trendUp} />}
                                {ward.status === 'down' && <TrendingDown size={20} className={styles.trendDown} />}
                                {ward.status === 'same' && <Minus size={20} className={styles.trendSame} />}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
}
