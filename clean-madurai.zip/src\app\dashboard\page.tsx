'use client';
import Link from 'next/link';
import { PlusCircle, Clock, CheckCircle } from 'lucide-react';
import styles from './dashboard-overview.module.css';

export default function CitizenDashboard() {
    // Mock data for MVP
    const stats = [
        { label: 'Reported Issues', value: 12, icon: <PlusCircle size={24} className={styles.statIcon} /> },
        { label: 'Pending Resolution', value: 3, icon: <Clock size={24} className={styles.statIcon} /> },
        { label: 'Resolved', value: 9, icon: <CheckCircle size={24} className={styles.statIcon} /> },
    ];

    return (
        <div className={styles.container}>
            <div className={styles.welcomeSection}>
                <h1 className={styles.welcomeText}>Welcome back to Citizen Hub</h1>
                <p className={styles.welcomeSub}>Here&apos;s an overview of your recent contributions to a cleaner Madurai.</p>
                <Link href="/dashboard/report" className={styles.actionBtn}>
                    <PlusCircle size={20} /> Report New Issue
                </Link>
            </div>

            <div className={styles.statsGrid}>
                {stats.map((stat, i) => (
                    <div key={i} className={`glass ${styles.statCard}`}>
                        {stat.icon}
                        <div className={styles.statContent}>
                            <div className={styles.statValue}>{stat.value}</div>
                            <div className={styles.statLabel}>{stat.label}</div>
                        </div>
                    </div>
                ))}
            </div>

            <div className={styles.recentSection}>
                <h2 className={styles.sectionTitle}>Recent Reports</h2>

                <div className={styles.reportsList}>
                    {/* Mock recent report */}
                    <div className={`glass ${styles.reportCard}`}>
                        <div className={styles.reportImagePlaceholder}>📸</div>
                        <div className={styles.reportDetails}>
                            <h3 className={styles.reportTitle}>Overflowing Bin</h3>
                            <p className={styles.reportMeta}>Anna Nagar • 2 hours ago</p>
                            <span className={`${styles.statusBadge} ${styles.pendingBadge}`}>Pending Analysis</span>
                        </div>
                        <div className={styles.reportId}>#COMP-8822</div>
                    </div>

                    <div className={`glass ${styles.reportCard}`}>
                        <div className={styles.reportImagePlaceholder}>📸</div>
                        <div className={styles.reportDetails}>
                            <h3 className={styles.reportTitle}>Plastic Waste Dump</h3>
                            <p className={styles.reportMeta}>KK Nagar • 1 day ago</p>
                            <span className={`${styles.statusBadge} ${styles.resolvedBadge}`}>Resolved</span>
                        </div>
                        <div className={styles.reportId}>#COMP-7711</div>
                    </div>
                </div>
            </div>
        </div>
    );
}
